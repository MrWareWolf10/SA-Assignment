import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { ApiService } from '../api.service';
import { Contact } from '../../../models/contact.model';

@Component({
  selector: 'app-contacts-list',
  templateUrl: './contacts-list.component.html',
  styleUrl: './contacts-list.component.css'
})
export class ContactsListComponent implements OnInit {
  contacts: Contact[] = [];
  @Output() editContact = new EventEmitter<Contact>(); // Emit contact to edit

  constructor(private apiService: ApiService) {}

  ngOnInit(): void {
    this.loadContacts();
  }

  loadContacts(): void {
    this.apiService.getContacts().subscribe(
      (data) => {
        this.contacts = data;
      },
      (error) => {
        console.error('Error loading contacts:', error);
      }
    );
  }

  deleteContact(id: number): void {
    this.apiService.deleteContact(id).subscribe(
      () => {
        this.contacts = this.contacts.filter(contact => contact.id !== id);
      },
      (error) => {
        console.error('Error deleting contact:', error);
      }
    );
  }

  // Emit selected contact for editing
  onEditContact(contact: Contact): void {
    this.editContact.emit(contact);
  }
}