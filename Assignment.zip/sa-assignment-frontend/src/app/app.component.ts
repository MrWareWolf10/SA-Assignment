import { Component, ViewChild } from '@angular/core';
import { Contact } from '../../models/contact.model';
import { ContactsListComponent } from './contacts-list/contacts-list.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  @ViewChild(ContactsListComponent) contactsList!: ContactsListComponent;
  contactToEdit: Contact | null = null;
  showForm: boolean = false; // Controls visibility of form

  // Show form to add a new contact
  onNewContact() {
    this.contactToEdit = null; // Ensure form is in "create" mode
    this.showForm = true;      // Show the form
  }

  // Show form to edit a selected contact
  onEditContact(contact: Contact) {
    this.contactToEdit = contact; // Set the contact to edit
    this.showForm = true;         // Show the form
  }

  // Called when a contact is saved or canceled
  onContactSaved() {
    this.contactsList.loadContacts(); // Refresh the contacts list
    this.showForm = false;            // Hide the form after saving
    this.contactToEdit = null;        // Reset contactToEdit
  }

  // Called to cancel form display without saving
  onCancel() {
    this.showForm = false;            // Hide the form
    this.contactToEdit = null;        // Reset contactToEdit
  }
}