import { Component, OnInit, Input, Output, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ApiService } from '../api.service';
import { Contact } from '../../../models/contact.model';

@Component({
  selector: 'app-contact-form',
  templateUrl: './contact-form.component.html',
  styleUrl: './contact-form.component.css'
})
export class ContactFormComponent implements OnInit, OnChanges {
  @Input() contactToEdit: Contact | null = null;
  @Output() contactSaved = new EventEmitter<void>(); 
  @Output() cancel = new EventEmitter<void>(); // Emit event when canceling
  contactForm: FormGroup;
  isEditMode = false;

  constructor(private fb: FormBuilder, private apiService: ApiService) {
    this.contactForm = this.fb.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]]
    });
  }

  ngOnInit(): void {}

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['contactToEdit'] && this.contactToEdit) {
      this.isEditMode = true;
      this.contactForm.patchValue(this.contactToEdit);
    } else {
      this.isEditMode = false;
      this.contactForm.reset();
    }
  }

  onSubmit(): void {
    if (this.contactForm.valid) {
      const contact: Contact = {
        ...this.contactForm.value,
        id: this.contactToEdit ? this.contactToEdit.id : 0 
      };

      if (this.isEditMode) {
        this.apiService.updateContact(contact.id, contact).subscribe(
          () => {
            console.log('Contact updated successfully');
            this.contactSaved.emit(); // Emit event to notify save
            this.resetForm();
          },
          (error) => {
            console.error('Error updating contact:', error);
          }
        );
      } else {
        this.apiService.createContact(contact).subscribe(
          () => {
            console.log('Contact created successfully');
            this.contactSaved.emit(); // Emit event to notify save
            this.resetForm();
          },
          (error) => {
            console.error('Error creating contact:', error);
          }
        );
      }
    }
  }

  // Reset form and clear edit mode
  resetForm(): void {
    this.contactForm.reset();
    this.isEditMode = false;
    this.contactToEdit = null;
  }

  // Emit the cancel event to hide form without saving
  onCancelClick(): void {
    this.cancel.emit();
    this.resetForm();
  }
}