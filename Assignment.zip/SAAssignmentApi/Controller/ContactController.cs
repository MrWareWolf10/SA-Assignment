﻿using SAAssignmentApi.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;

namespace SAAssignmentApi.Controller
{
	[Route("api/[controller]")]
	[ApiController]
	public class ContactsController : ControllerBase
	{
		private readonly string _filePath = Path.Combine(Directory.GetCurrentDirectory(), "contacts.json");

		private List<Contacts> LoadContactsFromFile()
		{
			if (!System.IO.File.Exists(_filePath))
			{
				System.IO.File.WriteAllText(_filePath, "[]");
			}

			var jsonData = System.IO.File.ReadAllText(_filePath);
			return JsonSerializer.Deserialize<List<Contacts>>(jsonData) ?? new List<Contacts>();
		}

		private void SaveContactsToFile(List<Contacts> contacts)
		{
			var jsonData = JsonSerializer.Serialize(contacts);
			System.IO.File.WriteAllText(_filePath, jsonData);
		}

		[HttpGet]
		public ActionResult<IEnumerable<Contacts>> GetContacts()
		{
			var contacts = LoadContactsFromFile();
			return Ok(contacts);
		}

		[HttpGet("{id}")]
		public ActionResult<Contacts> GetContact(int id)
		{
			var contacts = LoadContactsFromFile();
			var contact = contacts.FirstOrDefault(c => c.Id == id);

			if (contact == null)
			{
				return NotFound();
			}

			return Ok(contact);
		}

		[HttpPost]
		public ActionResult<Contacts> CreateContact([FromBody] Contacts contact)
		{
			var contacts = LoadContactsFromFile();
			contact.Id = contacts.Count > 0 ? contacts.Max(c => c.Id) + 1 : 1;
			contacts.Add(contact);
			SaveContactsToFile(contacts);

			return CreatedAtAction(nameof(GetContact), new { id = contact.Id }, contact);
		}

		[HttpPut("{id}")]
		public IActionResult UpdateContact(int id, [FromBody] Contacts updatedContact)
		{
			var contacts = LoadContactsFromFile();
			var contact = contacts.FirstOrDefault(c => c.Id == id);

			if (contact == null)
			{
				return NotFound();
			}

			contact.FirstName = updatedContact.FirstName;
			contact.LastName = updatedContact.LastName;
			contact.Email = updatedContact.Email;

			SaveContactsToFile(contacts);
			return NoContent();
		}

		[HttpDelete("{id}")]
		public IActionResult DeleteContact(int id)
		{
			var contacts = LoadContactsFromFile();
			var contact = contacts.FirstOrDefault(c => c.Id == id);

			if (contact == null)
			{
				return NotFound();
			}

			contacts.Remove(contact);
			SaveContactsToFile(contacts);
			return NoContent();
		}
	}
}
